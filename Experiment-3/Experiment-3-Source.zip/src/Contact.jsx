import React from 'react';

const Contact = () => {
    return (
        <div style={{ padding: '20px', textAlign: 'center' }}>
            <h1>Contact Page</h1>
            <p>This is the Contact Page.</p>
        </div>
    );
};

export default Contact;
